package commands;

public interface Command {
    /**
     * The method implemented by the concrete commands
     */
    void execute();
}
